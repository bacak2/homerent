<?php $__env->startSection('content'); ?>
    <div class="form-logowanie">
        <div class="log">
            <h2 style="padding-bottom: 10px;">Zaloguj się</h2>      
            <center><a href="http://facebook.com"><img src="<?php echo e(asset('images/fb-log.png')); ?>"></a></center>
                <p class="form">Nie publikujemy na tablicy bez Twojej zgody</p>
                <p class="form">Logując się przez Facebooka otrzymujesz <b>5% zniżki</b> na pierwszą rezerwację</p>

                    <form class="logowanie" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email">Login</label>
                                <input id="login" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>

                                <input type="submit" id="submit" value="Zaloguj">
                    </form><br><br>
                      <a style="text-decoration:none; color:black" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>