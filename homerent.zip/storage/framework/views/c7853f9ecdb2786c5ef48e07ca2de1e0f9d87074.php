<!DOCTYPE html>
<html>
<head>
	<title>Homerent <?php echo $__env->yieldContent('title'); ?></title>
	
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/homerent.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/jquery-date-range-picker/src/daterangepicker.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/fotorama.css')); ?>" rel="stylesheet">
	
	<script type="text/javascript" src="<?php echo e(asset('vendor/moment/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/jquery-date-range-picker/dist/jquery.daterangepicker.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('vendor/fotorama/fotorama.js')); ?>"></script>
	
    <script src="<?php echo e(asset('vendor/easy-autocomplete/dist/jquery.easy-autocomplete.min.js')); ?>"></script> 
	<link rel="stylesheet" href="<?php echo e(asset('vendor/easy-autocomplete/dist/easy-autocomplete.min.css')); ?>"> 
	<link rel="stylesheet" href="<?php echo e(asset('vendor/easy-autocomplete/dist/easy-autocomplete.themes.min.css')); ?>"> 

<body>
	
	<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<?php echo $__env->yieldContent('content'); ?>
	
	<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->make('includes.privacy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>