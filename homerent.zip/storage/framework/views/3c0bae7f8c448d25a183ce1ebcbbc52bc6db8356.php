<?php $__env->startSection('title', '- Wyszukiwarka'); ?>
<?php $__env->startSection('content'); ?>
<div class="container pt-5 pb-5 results-search">
<div class="col">
  <form class="wyszukiwarka" action="/search" method="GET" >
    <div class="form-row">
      <div class="col-md-3 mb-2 mb-sm-0">
        <input type="text" class="form-control" id="region" name="region" placeholder="<?php echo e(__('messages.forexample')); ?>" value="<?php echo e($region); ?>" >
      </div>
      <div class="form-inline col-md-4 form-row pick-date ">
          <div class="col-md-6 mb-2 mb-sm-0">
              <div class="input-group mb-2 mb-sm-0">
                  <div class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                  <input type="text" class="form-control" id="przyjazd" name="przyjazd" placeholder="<?php echo e(__('messages.arrive')); ?>" pattern="(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))" value="<?php echo e($arive_date); ?>" required>
              </div>
          </div>
          <div class="col-md-6 mb-2 mb-sm-0">
              <div class="input-group mb-2 mb-sm-0">
                  <div class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                  <input type="text" class="form-control" id="powrot" name="powrot" placeholder="<?php echo e(__('messages.return')); ?>" pattern="(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))" value="<?php echo e($return_date); ?>" required>
              </div>
          </div>
      </div>
      <div class="col-md">
          <div class="input-group mb-2 mb-sm-0">
            <div class="input-group-addon"><i class="fa fa-male" aria-hidden="true"></i></div>
            <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="<?php echo e(__('messages.adults')); ?>">
          </div>
      </div>
      <div class="col-md">
        <div class="input-group mb-2 mb-sm-0">
          <div class="input-group-addon"><i class="fa fa-child" aria-hidden="true"></i></div>
          <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="<?php echo e(__('messages.kids')); ?>">
        </div>
      </div>
      <div class="col-md">
        <button type="submit" class="btn btn-primary searchbtn"><?php echo e(__('messages.search')); ?></button>
      </div>
    </div>
  </form>
</div>
</div>
	<div class="container" id="apartamentsforyou">
	<h3 class="pb-2"><?php echo e(__('messages.found')); ?> <?php echo e($counted); ?> <?php echo e(trans_choice('messages.apartaments',$counted)); ?> 
	</h3>



		<div class="row">
			<?php $__currentLoopData = $finds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <a class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3" href="/apartaments/<?php echo e($apartament->apartament_link); ?>">
		        <div style="background-image: url('<?php echo e(asset('images/1.jpg')); ?>');"  class="apartament">
		        <p class="title"><?php echo e($apartament->apartament_name); ?></p>

		      </div>
		      </a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 	
		</div>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>