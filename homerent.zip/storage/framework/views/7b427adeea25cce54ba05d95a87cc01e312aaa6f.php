<!DOCTYPE html>
<html>
<head>
	<title>Homerent <?php echo $__env->yieldContent('title'); ?></title>
	
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
	<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/forms.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/datepicker.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('ism/css/my-slider.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/fotorama.css')); ?>" rel="stylesheet">
	
	<script type="text/javascript" src="<?php echo e(asset('ism/js/ism-2.2.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/jquery.easyModal.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/fotorama.js')); ?>"></script>
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<body>

	<header>
		<div class="top-left">
			<a href="index.html"><img src="images/logo.png" alt="Logo"></a>
		</div>
		<div class="top-right">
			<div class="top-right-wrapper">
				<button class='add_apartament'>Dodaj apartament</button>
	 		</div>	
	 		<div class="top-right-wrapper-right">
	 		<div class="top-buttons">
				<a href="#"><button class='top-button'>Ulubione</button></a>
				<font color="#a8b7c3">|</font>
				<button class="easy-modal-open" href="#logowanie">Logowanie</button>
				<font color="#a8b7c3">|</font>
				<button class="easy-modal-open" href="#rejestracja">Rejestracja</button>
				</div>
	 		</div>
		</div>
	</header>

	<?php echo $__env->yieldContent('search'); ?>
	<?php echo $__env->yieldContent('benifits'); ?>

	<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
	</body>
</html>