    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: white;" >
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Homerent</a>
			<div class="row mx-auto">        
		    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <a style="text-decoration: none;" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
		                <img src="<?php echo e(asset("images/flags/".$localeCode.".gif")); ?>">&nbsp;
		            </a>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navMenuTop" aria-controls="navMenuTop" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMenuTop">
          <ul class="navbar-nav ml-auto">
          	<?php if(auth()->guard()->guest()): ?>
	            <li class="nav-item">
	              <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('messages.login')); ?></a>
	            </li>
	            <li class="nav-item">
	              <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('messages.register')); ?></a>
	            </li>
	        <?php else: ?> 
              <li class="nav-item">
               <div class="nav-link"><?php echo e(Auth::user()->name); ?> </div> 
              </li>
                <a href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                   <button class='btn '><?php echo e(__('messages.logout')); ?></button>
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
			<?php endif; ?>	        
          </ul>
        </div>
      </div>
    </nav>