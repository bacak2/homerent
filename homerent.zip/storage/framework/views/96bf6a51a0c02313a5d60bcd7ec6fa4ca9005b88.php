
	<footer>
		<div class="footer-container">
			<div class="foot">
				<h2 class="footer">Najpopularniejsze</h2>
				<ol class="footer">
				<li><a href="">Kraków</a></li>
				<li><a href="">Kraków</a></li>
				<li><a href="">Kraków</a></li>
				<li><a href="">Kraków</a></li>						
				</ol>
			</div>
			<div class="foot">
				<h2 class="footer">Pomoc</h2>
				<ol class="footer">
				<li><a href="">Lorem ipsum</a></li>
				<li><a href="">Lorem ipsum</a></li>
				<li><a href="">Lorem ipsum</a></li>
				<li><a href="">Lorem ipsum</a></li>						
				</ol>
			</div>
			<div class="foot">
				<h2 class="footer">O nas</h2>
				<ol class="footer">
				<li><a href="">Lorem ipsum</a></li>
				<li><a href="">Lorem ipsum</a></li>
				<li><a href="">Lorem ipsum</a></li>
				<li><a href="">Lorem ipsum</a></li>			
				</ol>		
			</div>
			<div class="foot2">
				<h2 class="footer">Bądź na bieżąco</h2>
				<img style="padding-top: 20px;" src="images/placeholderfbgoogle.jpg">
			</div>

			<div class="foot2">
				<h2 class="footer">Zapisz się do newslettera i korzystaj ze zniżek i ofert specjalnych</h2>
				<form class="newsletter">
					<input type="text" id="mail">
					<input type="submit" id="submitnews" value="Zapisz się" name="">
				</form>
			</div>

			<div class="dolnik">
				<h2 class="footer">Podróżuj razem z nami</h2>
				<p class="podrozuj">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus.</p>
			</div>

								
		</div>
	</footer>
	<div class="down-footer">
		<p class="down-footer">Aby zapewnić najwyższą jakość usług wykorzystujemy informacje przechowywane w przeglądarce internetowej.<br>
		Sprawdź cel, warunki przechowywania lub dostępu do nich w <a class="privacy" href="#">Polityce prywatności</a>
	</p>
	</div>