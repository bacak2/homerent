<?php $__env->startSection('title', '- Strona główna'); ?>

		
	<?php $__env->startSection('search'); ?>
			<div id="search-slider">
				<div class="search">
					<div class="search-wrapper">
						<div class="region">Wpisz miasto, region lub adres</div>
						<div class="przyjazd">Przyjazd</div>
						<div class="przyjazd">Powrót</div>
					<form action="wyniki.html" method="POST" class="form-search">
						<input type="text" id="region" placeholder="np. Kraków lub Mazury">
						<input type="text" id="przyjazd">
						<input type="text" id="powrot">
						<input type="number"  value="0" min="0" max="100" id="nights" >
						<input type="number"  value="0" min="0" max="100" id="persons" >
						<input type="submit" id="submit" value="Szukaj">
					</div>
					</form>
				</div>

			<div class="ism-slider" data-transition_type="fade" data-play_type="loop" data-image_fx="none" data-buttons="false" id="slider">
			  <ol>
			    <li>
			      <img src="ism/image/slides/tatry1.jpg">
			    </li>
			    <li>
			      <img src="ism/image/slides/krakow-city.jpg">
			    </li>
			    <li>
			      <img src="ism/image/slides/tatry2.jpg">
			    </li>
			    <li>
			      <img src="ism/image/slides/gdansk.jpg">
			    </li>
			  </ol>
			</div>
			</div>
	<?php $__env->stopSection(); ?>

		
	<?php $__env->startSection('benifits'); ?>
			<div id="benefits">
				<div class="ben1"><div class="benefit"><img src="images/procent.png" class="img-ben" alt="tanio">
				<h3>Tanio</h3>
				<p class="ben-descreption">Około 50% taniej niż za hotel.</p>
				</div></div>
				<div class="ben2"><div class="benefit"><img src="images/time.png" class="img-ben" alt="szybko">
				<h3>Szybko</h3>
				<p class="ben-descreption">Zarezerwuj od razu i tylko czekaj na wyjazd.</p>
				</div></div>
				<div class="ben3"><div class="benefit"><img src="images/up.png" class="img-ben" alt="bezpiecznie">
				<h3>Bezpiecznie</h3>
				<p class="ben-descreption">Zaufało nam 23,765 klientów.<br>Znajdź obiekt i sprawdź opinie.</p>
				</div></div>
			</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>