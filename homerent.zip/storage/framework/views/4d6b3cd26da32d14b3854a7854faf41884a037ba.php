<?php $__env->startSection('title', '- Strona główna'); ?>
<?php $__env->startSection('content'); ?>
	
	<?php echo $__env->make('includes.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<section>
	
	<?php echo $__env->make('includes.benifits', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<div class="container" id="apartamentsforyou">
		<h3><?php echo e(__('messages.ap4u')); ?></h3>
		<div class="container">
		    <div class="row">
				<?php $__currentLoopData = $apartaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			      <a class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3" href="/apartaments/<?php echo e($apartament->apartament_link); ?>">
			        <div style="background-image: url('<?php echo e(asset('images/1.jpg')); ?>');"  class="apartament">
			        <p class="title"><?php echo e($apartament->apartament_name); ?></p>
			        <p class="price pb-1 pt-1"><b><?php echo e(__('messages.from')); ?> <?php echo e($apartament->price_value); ?> <?php echo e(__('messages.pernight')); ?></b></p>
			      </div>
			      </a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </div>
		</div>
	</div>
	</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>