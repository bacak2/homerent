<div class="container" id="benifits">
 <div class="row">
    <div class="col-md-3 col-sm-6">
      <div><img src="{{ asset('images/procent.png') }}" class="rounded float-left" alt="t"></div><div><h4>{{ __('messages.cheap') }}</h4><p>{{ __('messages.placeholder') }}</p></div>
    </div>

    <div class="col-md-3 col-sm-6">
      <div><img src="{{ asset('images/time.png') }}" class="rounded float-left" alt="s"></div><div><h4>{{ __('messages.fast') }}</h4><p>{{ __('messages.placeholder') }}</p></div>
    </div>

    <div class="col-md-3 col-sm-6">
      <div><img src="{{ asset('images/up.png') }}" class="rounded float-left" alt="w"></div><div><h4>{{ __('messages.safe') }}</h4><p>{{ __('messages.placeholder') }}</p></div>
    </div>

    <div class="col-md-3 col-sm-6">
      <div><img src="{{ asset('images/procent.png') }}" class="rounded float-left" alt="y"></div><div><h4>{{ __('messages.cheap') }}</h4><p>{{ __('messages.placeholder') }}</p></div>
    </div>
</div> 
</div>