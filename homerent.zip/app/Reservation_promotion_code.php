<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reservation_promotion_code extends Model
{
    //
}
