<?php
/**
 *@category Kontroler rezerwacji, aplikacji HOMERENT
 *@author Arkadiusz Adamczyk
 *@version 1.0
 */


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class Reservations extends Controller
{
    







}
